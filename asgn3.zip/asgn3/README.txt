1) Install the necessary modules by typing "npm install" in the
nodejs project folder

2) Use browser to access http://localhost:8081/
