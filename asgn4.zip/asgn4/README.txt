0. You need to install the necessary modules first by typing "npm install"
in the folder containing tihs file.

1. You must have started mongodb first before running node.

2. Run "node initdb.js" to reset the data in the DB.

3. Run "node index.js" to start the server.


4. The routing task has been forwarded to js/asg4.js (from index.js).
   You should only need to modify "js/asgn4.js" in this assignment.

5. The assignment instructions are listed in asgn4.html.
